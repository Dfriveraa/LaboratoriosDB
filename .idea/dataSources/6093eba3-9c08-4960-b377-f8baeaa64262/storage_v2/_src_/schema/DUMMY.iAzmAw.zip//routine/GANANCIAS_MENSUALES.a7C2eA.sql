create function ganancias_mensuales(cedula empleo.ced%type)
    return empleo.VALOR_MENSUAL%Type
    IS
    ganancias empleo.VALOR_MENSUAL%Type;
    BEGIN
        SELECT sum(VALOR_MENSUAL) into ganancias from EMPLEO where CED = cedula;
        if ganancias is null then
            ganancias:=0;
            return ganancias;
        end if;
        return ganancias;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        ganancias:=0;
        return ganancias;
    END;
/

