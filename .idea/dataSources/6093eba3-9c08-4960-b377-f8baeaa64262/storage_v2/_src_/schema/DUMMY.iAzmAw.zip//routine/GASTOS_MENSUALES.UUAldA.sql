create function gastos_mensuales(cedula empleo.ced%type)
    return empleo.VALOR_MENSUAL%Type
    IS
    client cliente.CED%TYPE;
    gastos empleo.VALOR_MENSUAL%Type;
    BEGIN
        SELECT CED INTO client FROM GASTO WHERE CED=cedula group by CED;
        SELECT sum(VALOR_MENSUAL) into gastos from GASTO where CED = cedula;
        return gastos;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        gastos:=0;
        return gastos;
    END;
/

