create function gastos_mensuales(cedula empleo.ced%type)
    return empleo.VALOR_MENSUAL%Type
    IS
    gastos empleo.VALOR_MENSUAL%Type;
    BEGIN
        
        SELECT sum(VALOR_MENSUAL) into gastos from GASTO where CED = cedula;
        if gastos is null then
            gastos:=0;
            return gastos;
        end if;
        return gastos;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        gastos:=0;
        return gastos;
    END;
/

