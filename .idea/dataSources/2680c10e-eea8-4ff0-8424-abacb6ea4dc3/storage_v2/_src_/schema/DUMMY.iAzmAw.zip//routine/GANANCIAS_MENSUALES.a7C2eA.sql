create function ganancias_mensuales(cedula empleo.ced%type)
    return empleo.VALOR_MENSUAL%Type
    IS
    client cliente.CED%TYPE;
    ganancias empleo.VALOR_MENSUAL%Type;
    BEGIN
        SELECT CED INTO client FROM EMPLEO WHERE CED=cedula group by CED;
        SELECT sum(VALOR_MENSUAL) into ganancias from EMPLEO where CED = cedula;
        return ganancias;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        ganancias:=0;
        return ganancias;
    END;
/

