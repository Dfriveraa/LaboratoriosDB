create PACKAGE laboratorio IS
    FUNCTION masGaston RETURN gasto.ced%Type;
    FUNCTION mejorPagado RETURN empleo.ced%Type;
END;
/

