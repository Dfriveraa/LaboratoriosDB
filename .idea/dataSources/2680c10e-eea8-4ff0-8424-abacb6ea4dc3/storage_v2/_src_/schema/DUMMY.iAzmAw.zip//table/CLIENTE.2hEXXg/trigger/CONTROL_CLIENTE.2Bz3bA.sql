create trigger CONTROL_CLIENTE
    before insert or update or delete
    on CLIENTE
BEGIN
    case
        when inserting then
            insert into auditoria values(SYSDATE,'cliente','insert');
        when updating then
            insert into auditoria values(SYSDATE,'cliente','update');
        when deleting then
            insert into auditoria values(SYSDATE,'cliente','delete');
    end case;
END;
/

