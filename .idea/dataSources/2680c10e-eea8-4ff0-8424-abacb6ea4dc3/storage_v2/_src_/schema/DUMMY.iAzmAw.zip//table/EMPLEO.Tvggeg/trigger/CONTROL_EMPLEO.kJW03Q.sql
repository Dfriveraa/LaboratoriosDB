create trigger CONTROL_EMPLEO
    before insert or update or delete
    on EMPLEO
BEGIN
    case
        when inserting then
            insert into auditoria values(SYSDATE,'empleo','insert');
        when updating then
            insert into auditoria values(SYSDATE,'empleo','update');
        when deleting then
            insert into auditoria values(SYSDATE,'empleo','delete');
    end case;
END;
/

