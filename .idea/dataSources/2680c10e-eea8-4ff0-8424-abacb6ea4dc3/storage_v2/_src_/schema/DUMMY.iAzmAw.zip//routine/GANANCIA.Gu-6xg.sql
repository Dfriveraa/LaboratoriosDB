create function ganancia(cedula empleo.ced%type)
    return empleo.VALOR_MENSUAL%Type
    IS
    ganancias empleo.VALOR_MENSUAL%Type;
    BEGIN 
        SELECT sum(VALOR_MENSUAL) into ganancias from EMPLEO where CED = cedula;
        return ganancias;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN 
        return 0;
    END;
/

