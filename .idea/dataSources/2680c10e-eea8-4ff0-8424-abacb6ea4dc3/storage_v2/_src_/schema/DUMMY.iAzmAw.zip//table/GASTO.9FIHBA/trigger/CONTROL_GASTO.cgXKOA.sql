create trigger CONTROL_GASTO
    before insert or update or delete
    on GASTO
BEGIN
    case
        when inserting then
            insert into auditoria values(SYSDATE,'gasto','insert');
        when updating then
            insert into auditoria values(SYSDATE,'gasto','update');
        when deleting then
            insert into auditoria values(SYSDATE,'gasto','delete');
    end case;
END;
/

